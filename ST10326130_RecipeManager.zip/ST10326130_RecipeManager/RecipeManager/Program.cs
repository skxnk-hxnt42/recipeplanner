﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeManager
{
    public class Program
    {
        // Declare static lists to store recipes and ingredients
        public static List<Recipe> recipes = new List<Recipe>();
        public static List<Ingredient> ingredients = new List<Ingredient>();

        public static void Main(string[] args)
        {
            // Main loop to keep the program running until the user decides to exit
            bool keepRunning = true;

            while (keepRunning)
            {
                // Display the main menu options
                menu();
                // Prompt the user to press any key to continue or 'exit' to quit
                Console.WriteLine("Press any key to continue or 'exit' to quit.");
                string input = Console.ReadLine().ToLower();
                // Check if the user wants to exit the program
                if (input == "exit")
                {
                    keepRunning = false;
                }
            }
        }

        // Method to display the main menu
        public static void menu()
        {
            // Display the main menu options to the user
            Console.WriteLine("What would you like to do?");
            Console.WriteLine("1. Enter a recipe");
            Console.WriteLine("2. Display Recipes");
            Console.WriteLine("3. Scale a recipe");
            Console.WriteLine("4. Reset a recipe's quantities");
            Console.WriteLine("5. Clear all data");
            Console.WriteLine("6. Exit");

            // Read the user's choice from the console
            int choice = Convert.ToInt16(Console.ReadLine());

            // Execute the chosen option based on the user's input
            switch (choice)
            {
                case 1:
                    addRecipe(); // Add a new recipe
                    break;
                case 2:
                    displayRecipes(); // Display all recipes
                    break;
                case 3:
                    scaleRecipe(); // Scale a recipe
                    break;
                case 4:
                    resetRecipeQuantities(); // Reset a recipe's quantities
                    break;
                case 5:
                    clearAllData(); // Clear all data
                    break;
                case 6:
                    Environment.Exit(0); // Exit the application
                    break;
            }
        }

        // Method to add a new recipe
        public static void addRecipe()
        {
            // Prompt the user to enter the name of the recipe
            Console.WriteLine("Enter the name of the recipe:");
            string recipeName = Console.ReadLine();

            // Prompt the user to enter the number of ingredients
            Console.WriteLine("Enter the number of ingredients:");
            int numIngredients = Convert.ToInt16(Console.ReadLine());

            // Loop to add each ingredient to the recipe
            for (int i = 0; i < numIngredients; i++)
            {
                Ingredient ingredient = new Ingredient();
                Console.WriteLine($"Enter ingredient {i + 1} name:");
                ingredient.Name = Console.ReadLine();
                Console.WriteLine($"Enter ingredient {i + 1} quantity:");
                ingredient.Quantity = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine($"Enter ingredient {i + 1} unit of measurement:");
                ingredient.UnitOfMeasurement = Console.ReadLine();
                Console.WriteLine($"Enter ingredient {i + 1} calories:");
                ingredient.Calories = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine($"Enter ingredient {i + 1} food group:");
                ingredient.FoodGroup = Console.ReadLine();

                // Add the ingredient to the ingredients list
                ingredients.Add(ingredient);
            }

            // Prompt the user to enter the number of steps
            Console.WriteLine("Enter the number of steps:");
            int numSteps = Convert.ToInt16(Console.ReadLine());

            // Loop to add each step to the recipe
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step {i + 1} description:");
                string stepDescription = Console.ReadLine();
                // Create a new recipe with the entered details and add it to the recipes list
                recipes.Add(new Recipe(recipeName, ingredients, stepDescription));

                // Calculate and display the total calories for the newly added recipe
                double totalCalories = ingredients.Sum(ing => ing.Calories * ing.Quantity);
                if (totalCalories > 300)
                {
                    Console.WriteLine($"Warning: The total calories for the recipe '{recipeName}' is above 300.");
                }
            }
        }

        // Method to display all recipes
        public static void displayRecipes()
        {
            // Display the names of all recipes
            Console.WriteLine("Select a recipe to display:");
            foreach (var recipe in recipes.OrderBy(r => r.Name))
            {
                Console.WriteLine($"{recipe.Name}");
            }

            // Prompt the user to enter the name of the recipe they want to display
            Console.WriteLine("Enter the name of the recipe you want to display:");
            string selectedRecipeName = Console.ReadLine();

            // Display the full details of the selected recipe
            displayFullRecipeDetails(selectedRecipeName);
        }

        // Method to display the full details of a selected recipe
        public static void displayFullRecipeDetails(string recipeName)
        {
            // Find the recipe by name
            var recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipe != null)
            {
                // Display the recipe name and its ingredients
                Console.WriteLine($"Recipe Name: {recipe.Name}");
                foreach (var ingredient in recipe.Ingredients)
                {
                    Console.WriteLine($"- {ingredient.Name}: {ingredient.Quantity} {ingredient.UnitOfMeasurement}, {ingredient.Calories} calories, {ingredient.FoodGroup}");
                }
                // Display the recipe steps
                Console.WriteLine(recipe.StepsDescription);
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        // Method to scale a recipe
        public static void scaleRecipe()
        {
            // Prompt the user to enter the name of the recipe to scale
            Console.WriteLine("Enter the recipe name to scale:");
            string recipeName = Console.ReadLine();

            // Find the recipe by name
            var recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipe != null)
            {
                // Get the scaling factor from the user
                double scaleFactor = GetScaleFactor();
                // Scale each ingredient in the recipe
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredient.Quantity *= scaleFactor;
                }
                Console.WriteLine($"Scaled recipe '{recipeName}' by a factor of {scaleFactor}");
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        // Method to get the scaling factor from the user
        public static double GetScaleFactor()
        {
            Console.WriteLine("Enter the scaling factor (0.5, 2, or 3):");
            return Convert.ToDouble(Console.ReadLine());
        }

        // Method to reset the quantities of a recipe
        public static void resetRecipeQuantities()
        {
            // Prompt the user to enter the name of the recipe to reset
            Console.WriteLine("Enter the recipe name to reset:");
            string recipeName = Console.ReadLine();

            // Find the recipe by name
            var recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipe != null)
            {
                // Reset the quantity of each ingredient in the recipe to 1
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredient.Quantity = 1; // Assuming default quantity to 1
                }
                Console.WriteLine($"Reset recipe '{recipeName}' quantities.");
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        // Method to clear all data
        public static void clearAllData()
        {
            // Clear the recipes and ingredients lists
            recipes.Clear();
            ingredients.Clear();
            Console.WriteLine("All data cleared.");
        }
    }

    // Class to represent a recipe
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public string StepsDescription { get; set; }

        // Constructor for the Recipe class
        public Recipe(string name, List<Ingredient> ingredients, string stepsDescription)
        {
            Name = name;
            Ingredients = ingredients;
            StepsDescription = stepsDescription;
        }
    }

    // Class to represent an ingredient
    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string UnitOfMeasurement { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }
}
