
using System;
using System.Collections.Generic;
using RecipeManager;

namespace RecipeManager.Tests
{
    [TestClass]
    public class RecipeManagerTests
    {
        [TestMethod]
        public void Setup()
        {
            // Initialize or reset any shared resources before each test
            Program.recipes = new List<Recipe>();
            Program.ingredients = new List<Ingredient>();
        }

        [TestMethod]
        public void TestAddRecipe()
        {
            // Arrange
            var recipeName = "Test Recipe";
            var ingredient = new Ingredient
            {
                Name = "Test Ingredient",
                Quantity = 1,
                UnitOfMeasurement = "cup",
                Calories = 100,
                FoodGroup = "Test Group"
            };
            Program.ingredients.Add(ingredient);
            var stepDescription = "Test step";

            // Act
            Program.recipes.Add(new Recipe(recipeName, Program.ingredients, stepDescription));

            // Assert
            Assert.AreEqual(1, Program.recipes.Count);
            Assert.AreEqual(recipeName, Program.recipes[0].Name);
            Assert.AreEqual(1, Program.recipes[0].Ingredients.Count);
            Assert.AreEqual(stepDescription, Program.recipes[0].StepsDescription);
        }

    }
}
